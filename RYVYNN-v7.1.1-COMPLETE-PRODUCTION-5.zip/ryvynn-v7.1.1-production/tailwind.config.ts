import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        void: '#0a0a0a',
        flame: {
          dark: '#ff4500',
          DEFAULT: '#ff6b35',
          light: '#ffa07a',
          gold: '#ffd700',
        },
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};

export default config;
