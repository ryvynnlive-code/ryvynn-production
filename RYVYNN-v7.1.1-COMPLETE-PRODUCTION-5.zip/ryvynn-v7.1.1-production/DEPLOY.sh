#!/bin/bash
# RYVYNN v7.1.1 SOVEREIGN - One-Click Deploy Script

echo "🔥 DEPLOYING RYVYNN TO VERCEL 🔥"
echo ""

# Check if vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "Installing Vercel CLI..."
    npm install -g vercel
fi

# Deploy to production
echo "Deploying to production..."
vercel --prod --yes

echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo ""
echo "Next steps:"
echo "1. Add environment variables in Vercel Dashboard"
echo "2. Configure custom domain (ryvynn.live)"
echo "3. Test the deployment"
