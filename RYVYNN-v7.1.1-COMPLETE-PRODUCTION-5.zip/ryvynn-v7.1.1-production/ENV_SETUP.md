# ENVIRONMENT VARIABLES FOR VERCEL

Add these in Vercel Dashboard → Project Settings → Environment Variables

## Required for Core Functionality:

### Supabase (Get from: https://app.supabase.com)
```
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...your-anon-key
DATABASE_URL=postgresql://postgres:[PASSWORD]@db.YOUR-PROJECT.supabase.co:5432/postgres?pgbouncer=true
```

### Anthropic Claude API (Get from: https://console.anthropic.com)
```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

### OpenAI API (Get from: https://platform.openai.com)
```
OPENAI_API_KEY=sk-...
```

### Stripe (Get from: https://dashboard.stripe.com)
```
STRIPE_SECRET_KEY=sk_test_... (or sk_live_ for production)
STRIPE_WEBHOOK_SECRET=whsec_...
```

### Stripe Price IDs (Create products in Stripe Dashboard first)
```
NEXT_PUBLIC_STRIPE_PRICE_GLOW=price_...
NEXT_PUBLIC_STRIPE_PRICE_FLICKER=price_...
NEXT_PUBLIC_STRIPE_PRICE_SPARK=price_...
NEXT_PUBLIC_STRIPE_PRICE_RADIANT=price_...
NEXT_PUBLIC_STRIPE_PRICE_LUMINOUS=price_...
NEXT_PUBLIC_STRIPE_PRICE_TRANSCENDENT=price_...
```

### App Configuration
```
NEXT_PUBLIC_BASE_URL=https://ryvynn.live
```

## CRITICAL NOTES:

1. **Supabase Setup:**
   - Create new project at supabase.com
   - Go to SQL Editor
   - Run: `CREATE EXTENSION IF NOT EXISTS vector;`
   - Get DATABASE_URL from Settings → Database → Connection String

2. **Stripe Webhooks:**
   - In Stripe Dashboard → Developers → Webhooks
   - Add endpoint: https://ryvynn.live/api/webhooks/stripe
   - Select events: customer.subscription.*, invoice.*, checkout.session.completed
   - Copy webhook secret

3. **Deploy Order:**
   - Add ALL env variables FIRST
   - Then deploy
   - Then test
