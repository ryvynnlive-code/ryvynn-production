// Stripe Configuration - Tesla Grid Pricing
// RYVYNN v7.1.1 SOVEREIGN

import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
  typescript: true,
});

// === TESLA GRID PRICING TIERS ===

export const PRICING_TIERS = {
  FREE: {
    name: 'Free',
    price: 0,
    tokensPerMonth: 10,
    priceId: null,
  },
  GLOW: {
    name: 'Glow',
    price: 12, // $12/month
    tokensPerMonth: 60,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_GLOW,
  },
  FLICKER: {
    name: 'Flicker',
    price: 24,
    tokensPerMonth: 150,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_FLICKER,
  },
  SPARK: {
    name: 'Spark',
    price: 48,
    tokensPerMonth: 360,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_SPARK,
  },
  RADIANT: {
    name: 'Radiant',
    price: 96,
    tokensPerMonth: 900,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_RADIANT,
  },
  LUMINOUS: {
    name: 'Luminous',
    price: 240,
    tokensPerMonth: 2880,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_LUMINOUS,
  },
  TRANSCENDENT: {
    name: 'Transcendent',
    price: 936,
    tokensPerMonth: 14400,
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_TRANSCENDENT,
  },
} as const;

export type TierName = keyof typeof PRICING_TIERS;

export function getTierByPriceId(priceId: string): TierName | null {
  for (const [key, tier] of Object.entries(PRICING_TIERS)) {
    if (tier.priceId === priceId) {
      return key as TierName;
    }
  }
  return null;
}

export function getTokensForTier(tier: TierName): number {
  return PRICING_TIERS[tier].tokensPerMonth;
}

// === DONATION PRODUCTS ===

export const DONATION_AMOUNTS = [10, 25, 50, 100, 250, 500, 1000];

export async function createDonationSession(amount: number, email?: string): Promise<string> {
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'usd',
          product_data: {
            name: 'RYVYNN Foundation Donation',
            description: 'Supporting mental health recovery and crisis prevention',
          },
          unit_amount: amount * 100, // Convert to cents
        },
        quantity: 1,
      },
    ],
    customer_email: email,
    success_url: `${process.env.NEXT_PUBLIC_BASE_URL}/donate/success`,
    cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/donate`,
  });
  
  return session.url!;
}
