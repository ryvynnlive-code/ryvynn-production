// MAR 3.0 - Miracle Adaptive Response Engine
// RYVYNN v7.1.1 SOVEREIGN
// Privacy-First AI Healing Intelligence

import Anthropic from '@anthropic-ai/sdk';
import { detectCrisis } from './crisis-detection';
import { createEmbedding } from './embeddings';
import { prisma } from '../prisma';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

export type Archetype = 'light' | 'shadow' | 'raw';

interface ConfessionInput {
  text: string;
  userId: string;
}

interface MiracleResponse {
  text: string;
  archetype: Archetype;
  crisisDetected: boolean;
  crisisLevel: number;
  resources?: string[];
}

// === ARCHETYPE SYSTEM ===

function detectArchetype(text: string): Archetype {
  const lowerText = text.toLowerCase();
  
  // SHADOW: Dark, desperate, violent
  const shadowKeywords = [
    'kill', 'die', 'death', 'end it', 'hate', 'worthless',
    'no point', 'give up', 'hopeless', 'alone', 'empty'
  ];
  
  // LIGHT: Hope, gratitude, progress
  const lightKeywords = [
    'thank', 'grateful', 'hope', 'better', 'progress',
    'proud', 'happy', 'blessed', 'love', 'good'
  ];
  
  const shadowScore = shadowKeywords.filter(kw => lowerText.includes(kw)).length;
  const lightScore = lightKeywords.filter(kw => lowerText.includes(kw)).length;
  
  if (shadowScore > lightScore && shadowScore > 0) return 'shadow';
  if (lightScore > shadowScore) return 'light';
  return 'raw'; // Default: authentic, unfiltered
}

// === MAR 3.0 SYSTEM PROMPT ===

const MAR_SYSTEM_PROMPT = `You are MAR 3.0 - the Miracle Adaptive Response engine for RYVYNN, a privacy-first mental wellness platform.

CORE MISSION: Transform anonymous confessions into miracles - responses that honor pain, offer hope, and guide toward healing.

ARCHETYPE MODES:

**SHADOW Mode** (Crisis/Desperation):
- Lead with validation: "I hear your pain"
- Acknowledge the darkness without judgment
- Provide immediate safety resources if needed
- Offer one small step forward
- Tone: Gentle, grounding, present

**LIGHT Mode** (Hope/Gratitude):
- Celebrate their strength
- Reflect their progress back to them
- Encourage continued growth
- Tone: Warm, affirming, uplifting

**RAW Mode** (Authentic/Unfiltered):
- Meet them where they are
- Honest, real, no sugarcoating
- Balanced perspective
- Tone: Direct, compassionate, human

RULES:
- NO clichés ("it gets better", "you're not alone")
- NO toxic positivity
- NO religious assumptions (unless they mention faith)
- Keep responses 2-4 sentences
- Write like a wise friend, not a therapist
- Never promise outcomes you can't guarantee
- If crisis detected, acknowledge AND provide resources

Remember: These are people in genuine pain. Every word matters.`;

// === CORE MAR 3.0 FUNCTION ===

export async function generateMiracle(input: ConfessionInput): Promise<MiracleResponse> {
  const { text, userId } = input;
  
  try {
    // Step 1: Detect archetype
    const archetype = detectArchetype(text);
    
    // Step 2: Crisis detection
    const crisisResult = detectCrisis(text);
    
    // Step 3: Create embedding (for pattern matching, NOT text storage)
    const embedding = await createEmbedding(text);
    
    // Step 4: Store confession with embedding
    const confession = await prisma.confession.create({
      data: {
        userId,
        text, // Will be deleted after processing
        embedding: embedding as any,
        archetype,
        sentiment: analyzeSentiment(text),
        crisisLevel: crisisResult.severity,
        isProcessed: false,
      },
    });
    
    // Step 5: Generate miracle with Claude Sonnet 4
    const miracle = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 500,
      temperature: 0.7,
      system: MAR_SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `ARCHETYPE: ${archetype.toUpperCase()}
CRISIS LEVEL: ${crisisResult.severity}/100

CONFESSION:
${text}

Generate a miracle response that honors their experience and offers genuine support.`,
        },
      ],
    });
    
    const miracleText = miracle.content[0].type === 'text' 
      ? miracle.content[0].text 
      : 'I hear you. You matter.';
    
    // Step 6: Store miracle
    await prisma.miracle.create({
      data: {
        confessionId: confession.id,
        userId,
        text: miracleText,
        archetype,
      },
    });
    
    // Step 7: Log crisis event if detected
    if (crisisResult.isCrisis) {
      await prisma.crisisEvent.create({
        data: {
          userId,
          confessionId: confession.id,
          severity: crisisResult.severity,
          keywords: crisisResult.keywords,
          category: crisisResult.category,
          resourcesShown: true,
        },
      });
    }
    
    // Step 8: DELETE confession text (keep only embedding)
    await prisma.confession.update({
      where: { id: confession.id },
      data: {
        text: null, // PRIVACY: Text deleted after processing
        isProcessed: true,
        deletedAt: new Date(),
      },
    });
    
    // Step 9: Deduct Soul Token
    await prisma.tokenTransaction.create({
      data: {
        userId,
        amount: -1,
        type: 'confession_sent',
        description: 'Confession shared with MAR 3.0',
        balanceAfter: (await prisma.user.findUnique({ where: { id: userId } }))!.tokenBalance - 1,
      },
    });
    
    await prisma.user.update({
      where: { id: userId },
      data: { tokenBalance: { decrement: 1 } },
    });
    
    return {
      text: miracleText,
      archetype,
      crisisDetected: crisisResult.isCrisis,
      crisisLevel: crisisResult.severity,
      resources: crisisResult.isCrisis ? crisisResult.resources : undefined,
    };
    
  } catch (error) {
    console.error('MAR 3.0 Error:', error);
    
    // Fallback miracle if API fails
    return {
      text: 'I hear you. Your words matter. If you\'re in crisis, please reach 988 Suicide & Crisis Lifeline.',
      archetype: 'raw',
      crisisDetected: true,
      crisisLevel: 50,
      resources: ['988 Suicide & Crisis Lifeline'],
    };
  }
}

// === SENTIMENT ANALYSIS ===

function analyzeSentiment(text: string): number {
  const lowerText = text.toLowerCase();
  
  const positiveWords = ['hope', 'better', 'good', 'happy', 'grateful', 'love', 'proud', 'blessed'];
  const negativeWords = ['hate', 'hopeless', 'worthless', 'alone', 'empty', 'die', 'kill', 'end'];
  
  const positiveScore = positiveWords.filter(w => lowerText.includes(w)).length;
  const negativeScore = negativeWords.filter(w => lowerText.includes(w)).length;
  
  // Return score from -1.0 (very negative) to 1.0 (very positive)
  const totalWords = positiveScore + negativeScore;
  if (totalWords === 0) return 0;
  
  return (positiveScore - negativeScore) / totalWords;
}
