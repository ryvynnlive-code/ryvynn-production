// Crisis Detection System
// RYVYNN v7.1.1 SOVEREIGN
// 3-Layer Safety Protocol

export interface CrisisResult {
  isCrisis: boolean;
  severity: number; // 0-100
  keywords: string[];
  category: string;
  resources: string[];
}

// === CRISIS KEYWORDS (3 Severity Tiers) ===

const CRITICAL_KEYWORDS = [
  'kill myself', 'end my life', 'suicide', 'want to die',
  'going to die', 'commit suicide', 'take my life', 'shoot myself',
  'hang myself', 'overdose', 'jump off', 'end it all'
];

const HIGH_KEYWORDS = [
  'self harm', 'cut myself', 'hurt myself', 'harm myself',
  'no reason to live', 'better off dead', 'worthless',
  'give up on life', 'can\'t go on', 'no hope',
  'life is meaningless', 'want to disappear'
];

const MODERATE_KEYWORDS = [
  'depressed', 'hopeless', 'alone', 'empty',
  'dark thoughts', 'scared', 'breaking down',
  'can\'t cope', 'overwhelmed', 'desperate'
];

// === CRISIS CATEGORIES ===

const CATEGORIES = {
  SUICIDE: ['suicide', 'kill myself', 'end my life', 'want to die'],
  SELF_HARM: ['self harm', 'cut myself', 'hurt myself', 'harm myself'],
  VIOLENCE: ['hurt someone', 'kill them', 'violent', 'revenge'],
  SUBSTANCE: ['relapse', 'using again', 'drunk', 'high', 'drugs', 'alcohol'],
  TRAUMA: ['flashback', 'ptsd', 'assault', 'abuse', 'rape'],
  PANIC: ['panic attack', 'can\'t breathe', 'heart racing', 'dying'],
};

// === RESOURCES BY CATEGORY ===

const RESOURCES = {
  SUICIDE: [
    '988 Suicide & Crisis Lifeline - Call or text 988',
    'Crisis Text Line - Text HOME to 741741',
    'Veterans Crisis Line - Call 988, press 1',
  ],
  SELF_HARM: [
    '988 Suicide & Crisis Lifeline - Call or text 988',
    'Self-Injury Hotline - 1-800-DONT-CUT (366-8288)',
  ],
  VIOLENCE: [
    'National Domestic Violence Hotline - 1-800-799-7233',
    '911 - For immediate danger',
  ],
  SUBSTANCE: [
    'SAMHSA National Helpline - 1-800-662-4357 (24/7)',
    'AA Hotline - 1-800-839-1686',
    'NA Helpline - 1-844-289-0879',
  ],
  TRAUMA: [
    'RAINN Sexual Assault Hotline - 1-800-656-4673',
    '988 Suicide & Crisis Lifeline - Call or text 988',
  ],
  PANIC: [
    '988 Suicide & Crisis Lifeline - Call or text 988',
    'Crisis Text Line - Text HOME to 741741',
  ],
  DEFAULT: [
    '988 Suicide & Crisis Lifeline - Call or text 988',
    'Crisis Text Line - Text HOME to 741741',
  ],
};

// === CORE DETECTION FUNCTION ===

export function detectCrisis(text: string): CrisisResult {
  const lowerText = text.toLowerCase();
  let severity = 0;
  const detectedKeywords: string[] = [];
  let category = 'DEFAULT';
  
  // Check CRITICAL keywords (severity 80-100)
  for (const keyword of CRITICAL_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      severity = Math.max(severity, 90);
      detectedKeywords.push(keyword);
    }
  }
  
  // Check HIGH keywords (severity 50-79)
  for (const keyword of HIGH_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      severity = Math.max(severity, 65);
      detectedKeywords.push(keyword);
    }
  }
  
  // Check MODERATE keywords (severity 30-49)
  for (const keyword of MODERATE_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      severity = Math.max(severity, 40);
      detectedKeywords.push(keyword);
    }
  }
  
  // Determine category
  for (const [cat, keywords] of Object.entries(CATEGORIES)) {
    if (keywords.some(kw => lowerText.includes(kw))) {
      category = cat;
      break;
    }
  }
  
  // Contextual severity boosters
  if (lowerText.includes('today') || lowerText.includes('tonight') || lowerText.includes('now')) {
    severity += 20; // Immediate intent
  }
  
  if (lowerText.includes('plan') || lowerText.includes('ready') || lowerText.includes('prepared')) {
    severity += 15; // Planned action
  }
  
  // Cap at 100
  severity = Math.min(severity, 100);
  
  const isCrisis = severity >= 50;
  
  return {
    isCrisis,
    severity,
    keywords: detectedKeywords,
    category,
    resources: RESOURCES[category as keyof typeof RESOURCES] || RESOURCES.DEFAULT,
  };
}

// === TESTING ===

export function testCrisisDetection() {
  const tests = [
    { text: 'I want to kill myself tonight', expected: true },
    { text: 'I feel hopeless and alone', expected: false },
    { text: 'I am planning to hurt myself', expected: true },
    { text: 'just feeling down today', expected: false },
  ];
  
  console.log('CRISIS DETECTION TESTS:');
  tests.forEach(({ text, expected }) => {
    const result = detectCrisis(text);
    const pass = result.isCrisis === expected;
    console.log(`${pass ? '✅' : '❌'} "${text}" -> Crisis: ${result.isCrisis}, Severity: ${result.severity}`);
  });
}
