// Stripe Webhook Handler
// POST /api/webhooks/stripe

import { NextRequest, NextResponse } from 'next/server';
import { stripe, getTierByPriceId, getTokensForTier } from '@/lib/stripe/config';
import { prisma } from '@/lib/prisma';
import Stripe from 'stripe';

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get('stripe-signature')!;
    
    let event: Stripe.Event;
    
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    } catch (err) {
      console.error('Webhook signature verification failed:', err);
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 400 }
      );
    }
    
    // Handle the event
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(subscription);
        break;
      }
      
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionCanceled(subscription);
        break;
      }
      
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        if (invoice.subscription) {
          await handlePaymentSucceeded(invoice);
        }
        break;
      }
      
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }
      
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        
        if (session.mode === 'subscription') {
          await handleCheckoutCompleted(session);
        } else if (session.mode === 'payment') {
          // Handle one-time payment (donation)
          await handleDonation(session);
        }
        break;
      }
    }
    
    return NextResponse.json({ received: true });
    
  } catch (error) {
    console.error('Webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    );
  }
}

async function handleSubscriptionUpdate(subscription: Stripe.Subscription) {
  const customerId = subscription.customer as string;
  const priceId = subscription.items.data[0].price.id;
  const tier = getTierByPriceId(priceId);
  
  if (!tier) {
    console.error('Unknown price ID:', priceId);
    return;
  }
  
  await prisma.subscription.upsert({
    where: { stripeCustomerId: customerId },
    update: {
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      tier: tier.toLowerCase(),
      status: subscription.status,
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
    create: {
      user: {
        connectOrCreate: {
          where: { id: subscription.metadata.userId },
          create: {
            id: subscription.metadata.userId,
            isAnonymous: false,
            tokenBalance: getTokensForTier(tier),
          },
        },
      },
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      tier: tier.toLowerCase(),
      status: subscription.status,
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    },
  });
}

async function handleSubscriptionCanceled(subscription: Stripe.Subscription) {
  await prisma.subscription.update({
    where: { stripeSubscriptionId: subscription.id },
    data: {
      status: 'canceled',
      cancelAtPeriodEnd: true,
    },
  });
}

async function handlePaymentSucceeded(invoice: Stripe.Invoice) {
  const subscription = await prisma.subscription.findUnique({
    where: { stripeSubscriptionId: invoice.subscription as string },
    include: { user: true },
  });
  
  if (subscription) {
    // Refresh tokens on successful payment
    const tokens = getTokensForTier(subscription.tier.toUpperCase() as any);
    
    await prisma.user.update({
      where: { id: subscription.userId },
      data: { tokenBalance: tokens },
    });
    
    await prisma.tokenTransaction.create({
      data: {
        userId: subscription.userId,
        amount: tokens,
        type: 'subscription_refresh',
        description: `Monthly refresh - ${subscription.tier}`,
        balanceAfter: tokens,
      },
    });
  }
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  await prisma.subscription.update({
    where: { stripeSubscriptionId: invoice.subscription as string },
    data: { status: 'past_due' },
  });
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const customerId = session.customer as string;
  const subscriptionId = session.subscription as string;
  const userId = session.metadata?.userId;
  
  if (!userId) return;
  
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  const priceId = subscription.items.data[0].price.id;
  const tier = getTierByPriceId(priceId);
  
  if (!tier) return;
  
  await prisma.subscription.create({
    data: {
      userId,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscriptionId,
      stripePriceId: priceId,
      tier: tier.toLowerCase(),
      status: subscription.status,
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    },
  });
  
  // Grant initial tokens
  await prisma.user.update({
    where: { id: userId },
    data: { tokenBalance: getTokensForTier(tier) },
  });
}

async function handleDonation(session: Stripe.Checkout.Session) {
  await prisma.donation.create({
    data: {
      stripePaymentId: session.payment_intent as string,
      amount: session.amount_total!,
      currency: session.currency!,
      donorEmail: session.customer_email,
      donorName: session.metadata?.donorName,
      isAnonymous: session.metadata?.isAnonymous === 'true',
      fundType: session.metadata?.fundType || 'foundation',
    },
  });
}
