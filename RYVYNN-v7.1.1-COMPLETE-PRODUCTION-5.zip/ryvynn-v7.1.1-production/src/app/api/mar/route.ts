// MAR 3.0 API Route
// POST /api/mar

import { NextRequest, NextResponse } from 'next/server';
import { generateMiracle } from '@/lib/mar/mar-3.0';
import { createClient } from '@/lib/supabase/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: NextRequest) {
  try {
    const { text } = await request.json();
    
    if (!text || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Confession text is required' },
        { status: 400 }
      );
    }
    
    // Get user (anonymous or authenticated)
    const supabase = await createClient();
    const { data: { user: supabaseUser } } = await supabase.auth.getUser();
    
    let userId: string;
    
    if (supabaseUser) {
      // Authenticated user
      userId = supabaseUser.id;
      
      // Ensure user exists in database
      await prisma.user.upsert({
        where: { id: userId },
        update: { lastActive: new Date() },
        create: {
          id: userId,
          email: supabaseUser.email,
          isAnonymous: false,
          tokenBalance: 10,
        },
      });
    } else {
      // Anonymous user - create or get from session
      const sessionId = request.cookies.get('ryvynn_session')?.value;
      
      if (sessionId) {
        const existingUser = await prisma.user.findFirst({
          where: { id: sessionId },
        });
        
        if (existingUser) {
          userId = existingUser.id;
        } else {
          // Create new anonymous user
          const newUser = await prisma.user.create({
            data: {
              isAnonymous: true,
              tokenBalance: 10,
            },
          });
          userId = newUser.id;
        }
      } else {
        // Create new anonymous user
        const newUser = await prisma.user.create({
          data: {
            isAnonymous: true,
            tokenBalance: 10,
          },
        });
        userId = newUser.id;
      }
    }
    
    // Check token balance
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });
    
    if (!user || user.tokenBalance < 1) {
      return NextResponse.json(
        { error: 'Insufficient Soul Tokens. Please upgrade your plan.' },
        { status: 403 }
      );
    }
    
    // Generate miracle
    const miracle = await generateMiracle({
      text,
      userId,
    });
    
    // Set session cookie for anonymous users
    const response = NextResponse.json({
      success: true,
      miracle: miracle.text,
      archetype: miracle.archetype,
      crisisDetected: miracle.crisisDetected,
      crisisLevel: miracle.crisisLevel,
      resources: miracle.resources,
      tokensRemaining: user.tokenBalance - 1,
    });
    
    if (!supabaseUser) {
      response.cookies.set('ryvynn_session', userId, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 60 * 60 * 24 * 365, // 1 year
      });
    }
    
    return response;
    
  } catch (error) {
    console.error('MAR API Error:', error);
    return NextResponse.json(
      { error: 'Failed to process confession' },
      { status: 500 }
    );
  }
}
