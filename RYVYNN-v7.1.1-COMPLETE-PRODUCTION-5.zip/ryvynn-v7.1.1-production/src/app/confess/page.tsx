'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function ConfessPage() {
  const [confession, setConfession] = useState('');
  const [miracle, setMiracle] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [crisis, setCrisis] = useState<{detected: boolean; resources?: string[]}>({detected: false});
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMiracle(null);
    
    try {
      const response = await fetch('/api/mar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: confession }),
      });
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to process confession');
      }
      
      const data = await response.json();
      setMiracle(data.miracle);
      setCrisis({
        detected: data.crisisDetected,
        resources: data.resources,
      });
      setConfession(''); // Clear confession
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-void text-white">
      {/* Crisis Bar */}
      <div className="fixed top-0 left-0 right-0 bg-flame-dark py-2 px-4 text-center text-sm font-bold z-50">
        🔥 CRISIS? CALL/TEXT 988 - Suicide & Crisis Lifeline 🔥
      </div>
      
      <div className="pt-20 px-4 max-w-4xl mx-auto pb-12">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="text-4xl">🔥</Link>
          <h1 className="text-5xl font-bold mt-4 mb-2 bg-gradient-to-r from-flame-dark via-flame to-flame-gold bg-clip-text text-transparent">
            Confess
          </h1>
          <p className="text-gray-400">
            Share your darkness. Receive a miracle. 100% anonymous.
          </p>
        </div>
        
        {/* Confession Form */}
        {!miracle && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <textarea
              value={confession}
              onChange={(e) => setConfession(e.target.value)}
              placeholder="Type your confession here... Everything you share is anonymous and will be deleted after processing."
              className="w-full h-64 bg-gray-900 border border-gray-800 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:border-flame resize-none"
              disabled={loading}
            />
            
            {error && (
              <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded">
                {error}
              </div>
            )}
            
            <button
              type="submit"
              disabled={loading || !confession.trim()}
              className="w-full py-4 bg-flame hover:bg-flame-light disabled:bg-gray-800 disabled:text-gray-500 text-white font-bold text-xl rounded-lg transition-all transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed"
            >
              {loading ? 'Transforming...' : 'Transform into Miracle'}
            </button>
            
            <p className="text-xs text-gray-500 text-center">
              Your confession will be processed with MAR 3.0 AI and immediately deleted. Only a mathematical vector is stored for pattern matching.
            </p>
          </form>
        )}
        
        {/* Miracle Response */}
        {miracle && (
          <div className="space-y-6">
            {crisis.detected && crisis.resources && (
              <div className="bg-flame-dark/20 border-2 border-flame rounded-lg p-6">
                <h2 className="text-2xl font-bold text-flame mb-4">🚨 Immediate Support Available</h2>
                <div className="space-y-2">
                  {crisis.resources.map((resource, i) => (
                    <p key={i} className="text-white font-medium">{resource}</p>
                  ))}
                </div>
              </div>
            )}
            
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 border border-flame/30 rounded-lg p-8">
              <h2 className="text-2xl font-bold mb-4 text-flame-gold">Your Miracle</h2>
              <p className="text-lg text-gray-100 leading-relaxed whitespace-pre-wrap">{miracle}</p>
            </div>
            
            <button
              onClick={() => setMiracle(null)}
              className="w-full py-4 bg-gray-800 hover:bg-gray-700 text-white font-bold rounded-lg transition-all"
            >
              Share Another Confession
            </button>
          </div>
        )}
        
        {/* Back Link */}
        <div className="text-center mt-8">
          <Link href="/" className="text-gray-500 hover:text-flame">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
