'use client';

import Link from 'next/link';

const TIERS = [
  { name: 'Free', price: 0, tokens: 10, features: ['10 confessions/month', 'Anonymous by default', 'Crisis detection'] },
  { name: 'Glow', price: 12, tokens: 60, features: ['60 confessions/month', 'Priority processing', 'All free features'] },
  { name: 'Flicker', price: 24, tokens: 150, features: ['150 confessions/month', 'Advanced AI responses', 'All previous features'] },
  { name: 'Spark', price: 48, tokens: 360, features: ['360 confessions/month', 'Miracle history', 'Coming Soon: Dark Journal'] },
  { name: 'Radiant', price: 96, tokens: 900, features: ['900 confessions/month', 'Coming Soon: Witness Circles', 'All features'] },
  { name: 'Luminous', price: 240, tokens: 2880, features: ['2,880 confessions/month', 'Coming Soon: Avatar System', 'Premium support'] },
  { name: 'Transcendent', price: 936, tokens: 14400, features: ['14,400 confessions/month', 'Enterprise features', 'Foundation access'] },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-void text-white">
      {/* Crisis Bar */}
      <div className="fixed top-0 left-0 right-0 bg-flame-dark py-2 px-4 text-center text-sm font-bold z-50">
        🔥 CRISIS? CALL/TEXT 988 🔥
      </div>
      
      <div className="pt-20 px-4 max-w-7xl mx-auto pb-12">
        {/* Header */}
        <div className="text-center mb-12">
          <Link href="/" className="text-4xl">🔥</Link>
          <h1 className="text-5xl font-bold mt-4 mb-2 bg-gradient-to-r from-flame-dark via-flame to-flame-gold bg-clip-text text-transparent">
            Tesla Grid Pricing
          </h1>
          <p className="text-gray-400 text-lg">
            Choose your path. 80% stay free forever.
          </p>
        </div>
        
        {/* Pricing Grid */}
        <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
          {TIERS.map((tier) => (
            <div
              key={tier.name}
              className={`bg-gray-900 border rounded-lg p-6 ${
                tier.price > 0 ? 'border-gray-800' : 'border-flame'
              }`}
            >
              <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
              <div className="mb-4">
                <span className="text-4xl font-bold text-flame">${tier.price}</span>
                <span className="text-gray-500">/month</span>
              </div>
              <p className="text-gray-400 mb-4">{tier.tokens} Soul Tokens/month</p>
              <ul className="space-y-2 mb-6">
                {tier.features.map((feature, i) => (
                  <li key={i} className="text-sm text-gray-300">✓ {feature}</li>
                ))}
              </ul>
              {tier.price === 0 ? (
                <Link
                  href="/confess"
                  className="block w-full py-2 bg-flame hover:bg-flame-light text-center rounded font-bold transition-all"
                >
                  Start Free
                </Link>
              ) : (
                <button
                  disabled
                  className="w-full py-2 bg-gray-800 text-gray-500 rounded font-bold cursor-not-allowed"
                >
                  Coming Soon
                </button>
              )}
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link href="/" className="text-gray-500 hover:text-flame">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
