'use client';

import Link from 'next/link';

const AMOUNTS = [10, 25, 50, 100, 250, 500, 1000];

export default function DonatePage() {
  return (
    <div className="min-h-screen bg-void text-white">
      {/* Crisis Bar */}
      <div className="fixed top-0 left-0 right-0 bg-flame-dark py-2 px-4 text-center text-sm font-bold z-50">
        🔥 CRISIS? CALL/TEXT 988 🔥
      </div>
      
      <div className="pt-20 px-4 max-w-4xl mx-auto pb-12">
        <div className="text-center mb-12">
          <Link href="/" className="text-4xl">🔥</Link>
          <h1 className="text-5xl font-bold mt-4 mb-2 bg-gradient-to-r from-flame-dark via-flame to-flame-gold bg-clip-text text-transparent">
            Support RYVYNN Foundation
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Your donation funds crisis research, peer specialist training, and free access for those who can't afford it.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {AMOUNTS.map((amount) => (
            <button
              key={amount}
              disabled
              className="py-8 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded-lg font-bold text-2xl transition-all cursor-not-allowed opacity-50"
            >
              ${amount}
            </button>
          ))}
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4 text-flame">Where Your Donation Goes</h2>
          <ul className="space-y-2 text-gray-300">
            <li>✓ Crisis protocol development and testing</li>
            <li>✓ Free platform access for addiction recovery programs</li>
            <li>✓ Peer specialist certification and training</li>
            <li>✓ Youth mental health safety research</li>
            <li>✓ RYVYNN Foundation programs in Tucson, AZ</li>
          </ul>
        </div>
        
        <p className="text-center text-gray-500 mb-4">
          RYVYNN Foundation is a 501(c)(3) nonprofit (pending). Donations are tax-deductible.
        </p>
        
        <p className="text-center text-sm text-gray-600">
          Payment processing coming soon via Stripe.
        </p>
        
        <div className="text-center mt-8">
          <Link href="/" className="text-gray-500 hover:text-flame">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
