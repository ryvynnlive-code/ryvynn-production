'use client';

import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-void text-white">
      {/* Crisis Bar - Always Visible */}
      <div className="fixed top-0 left-0 right-0 bg-flame-dark text-white py-2 px-4 text-center text-sm font-bold z-50">
        🔥 CRISIS? CALL/TEXT 988 - Suicide & Crisis Lifeline 🔥
      </div>
      
      {/* Main Content */}
      <div className="pt-16 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Logo */}
        <div className="text-8xl mb-8">🔥</div>
        
        {/* Hero */}
        <h1 className="text-6xl md:text-8xl font-bold text-center mb-6 bg-gradient-to-r from-flame-dark via-flame to-flame-gold bg-clip-text text-transparent">
          RYVYNN
        </h1>
        
        <p className="text-2xl md:text-3xl text-gray-300 text-center max-w-3xl mb-4">
          From Our Darkest Hours to Our Brightest Days
        </p>
        
        <p className="text-lg text-gray-400 text-center max-w-2xl mb-12">
          Privacy-first AI mental wellness. Share your confession anonymously. Receive miracles. Zero surveillance. Zero judgment.
        </p>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            href="/confess"
            className="px-8 py-4 bg-flame hover:bg-flame-light text-white font-bold text-xl rounded-lg transition-all transform hover:scale-105"
          >
            Confess Now (Anonymous)
          </Link>
          
          <Link
            href="/pricing"
            className="px-8 py-4 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xl rounded-lg transition-all"
          >
            Tesla Grid Pricing
          </Link>
        </div>
        
        {/* Features */}
        <div className="grid md:grid-3 gap-8 max-w-5xl mt-20">
          <FeatureCard
            title="Anonymous by Default"
            description="No email required. No tracking. Your confessions are deleted after processing."
          />
          <FeatureCard
            title="AI-Powered Miracles"
            description="MAR 3.0 transforms your darkness into hope with Claude Sonnet 4."
          />
          <FeatureCard
            title="Crisis Detection"
            description="3-layer safety system with immediate 988 access and resources."
          />
        </div>
        
        {/* Footer */}
        <div className="mt-20 text-gray-500 text-center">
          <p>RYVYNN v7.1.1 SOVEREIGN</p>
          <p className="mt-2">NEXXT GEN INNOVATIONS LLC (DBA AONIXX)</p>
          <p className="mt-2">
            <Link href="/donate" className="text-flame hover:text-flame-light">
              Support RYVYNN Foundation
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="bg-gray-900 p-6 rounded-lg border border-gray-800">
      <h3 className="text-xl font-bold mb-2 text-flame">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  );
}
