import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'RYVYNN - From Our Darkest Hours to Our Brightest Days',
  description: 'Privacy-first AI mental wellness platform. Anonymous confessions, AI miracles, zero surveillance.',
};

export default function RootLayout({
  children,
}: {
  children: React.Node;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
