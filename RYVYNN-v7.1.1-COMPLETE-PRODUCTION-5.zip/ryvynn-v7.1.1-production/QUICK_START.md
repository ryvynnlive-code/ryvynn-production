# RYVYNN DEPLOYMENT - QUICK START

## Option 1: Deploy from Computer (FASTEST)

### If you already extracted the ZIP:

```bash
cd ryvynn-v7.1.1-production

# Deploy to Vercel
./DEPLOY.sh

# OR manually:
vercel --prod
```

### First time setup:
1. Vercel will ask you to login - follow the prompts
2. Select "ryvynn" team when prompted
3. Project name: "ryvynn-production"
4. Wait for deployment (~3 minutes)
5. Get deployment URL (e.g., ryvynn-production.vercel.app)

## Option 2: Deploy from GitHub

```bash
# Initialize git
git init
git add .
git commit -m "RYVYNN v7.1.1 SOVEREIGN - Initial deployment"

# Create GitHub repo (go to github.com/new)
# Then push:
git remote add origin https://github.com/YOUR-USERNAME/ryvynn-production.git
git branch -M main
git push -u origin main

# In Vercel Dashboard:
# - Import GitHub repo
# - Select "ryvynn" team
# - Add environment variables (see ENV_SETUP.md)
# - Deploy
```

## After Deployment:

### 1. Add Environment Variables
- Go to Vercel Dashboard → Project → Settings → Environment Variables
- Add ALL variables from ENV_SETUP.md
- Redeploy after adding variables

### 2. Configure Custom Domain
- Go to Vercel Dashboard → Project → Settings → Domains
- Add "ryvynn.live"
- Vercel will show DNS records
- You said DNS is already setup - verify it matches Vercel's requirements

### 3. Test Deployment
Visit your deployment URL and test:
- [ ] Homepage loads
- [ ] Crisis bar shows
- [ ] Can submit confession
- [ ] Receives miracle response
- [ ] Crisis detection works

## Troubleshooting:

### "Build failed"
- Check that ALL environment variables are added
- Ensure DATABASE_URL is correct
- Verify Supabase has pgvector extension

### "API returns 500"
- Check ANTHROPIC_API_KEY is valid
- Check OPENAI_API_KEY is valid
- Check Vercel logs for errors

### "DNS not resolving"
- DNS changes take 24-48 hours
- Use Vercel preview URL meanwhile
- Check https://dnschecker.org

## DONE!

Once deployed:
1. Share the URL with beta testers
2. Test confession flow end-to-end
3. Monitor Vercel logs for errors
4. Celebrate - YOU JUST DEPLOYED RYVYNN! 🔥
