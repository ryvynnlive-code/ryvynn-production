"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

// SETTINGS - Age/Gender/Region Personalization
// Used to customize AI responses contextually

type AgeTier = "teen" | "young_adult" | "adult" | "midlife" | "mature" | "elder";
type Gender = "male" | "female" | "non_binary" | "prefer_not_to_say";

interface UserProfile {
  age_tier: AgeTier;
  gender: Gender;
  region_code: string; // ISO 3166-2 format (e.g., US-NY, GB-SCT)
  ai_style: "plain" | "poetic" | "raw" | "clinical" | "empathetic";
  voice_tone: "masculine" | "feminine" | "neutral";
  avatar_name: string;
}

const AGE_TIERS = [
  { value: "teen" as AgeTier, label: "Teen (13-17)", description: "Age-appropriate, protective guidance" },
  { value: "young_adult" as AgeTier, label: "Young Adult (18-25)", description: "Navigating independence, identity formation" },
  { value: "adult" as AgeTier, label: "Adult (26-35)", description: "Career, relationships, life decisions" },
  { value: "midlife" as AgeTier, label: "Midlife (36-50)", description: "Family, purpose, transitions" },
  { value: "mature" as AgeTier, label: "Mature (51-65)", description: "Wisdom, legacy, health" },
  { value: "elder" as AgeTier, label: "Elder (66+)", description: "Life reflection, meaning, connection" },
];

const GENDERS = [
  { value: "male" as Gender, label: "Male" },
  { value: "female" as Gender, label: "Female" },
  { value: "non_binary" as Gender, label: "Non-Binary" },
  { value: "prefer_not_to_say" as Gender, label: "Prefer Not to Say" },
];

const AI_STYLES = [
  { value: "plain", label: "Plain Advice", description: "4th-5th grade reading level, no poetry, direct" },
  { value: "poetic", label: "Poetic/Metaphor", description: "Eloquent, symbolic, deeper meaning" },
  { value: "raw", label: "Direct/Raw", description: "18+ only, unfiltered truth" },
  { value: "clinical", label: "Clinical", description: "Formal, therapeutic language" },
  { value: "empathetic", label: "Empathetic", description: "Warm, compassionate, gentle" },
];

const VOICE_TONES = [
  { value: "masculine", label: "Masculine", description: "Deeper, grounded tone" },
  { value: "feminine", label: "Feminine", description: "Warm, nurturing tone" },
  { value: "neutral", label: "Neutral", description: "Balanced, no gender markers" },
];

// Common US states for quick selection
const US_STATES = [
  "US-AL", "US-AK", "US-AZ", "US-AR", "US-CA", "US-CO", "US-CT", "US-DE", "US-FL", "US-GA",
  "US-HI", "US-ID", "US-IL", "US-IN", "US-IA", "US-KS", "US-KY", "US-LA", "US-ME", "US-MD",
  "US-MA", "US-MI", "US-MN", "US-MS", "US-MO", "US-MT", "US-NE", "US-NV", "US-NH", "US-NJ",
  "US-NM", "US-NY", "US-NC", "US-ND", "US-OH", "US-OK", "US-OR", "US-PA", "US-RI", "US-SC",
  "US-SD", "US-TN", "US-TX", "US-UT", "US-VT", "US-VA", "US-WA", "US-WV", "US-WI", "US-WY"
];

export default function SettingsPage() {
  const [profile, setProfile] = useState<UserProfile>({
    age_tier: "adult",
    gender: "prefer_not_to_say",
    region_code: "US-NY",
    ai_style: "plain",
    voice_tone: "neutral",
    avatar_name: "My Dual Flame",
  });

  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = () => {
    const stored = localStorage.getItem("user_profile");
    if (stored) {
      setProfile(JSON.parse(stored));
    }
  };

  const saveProfile = () => {
    localStorage.setItem("user_profile", JSON.stringify(profile));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const updateProfile = (field: keyof UserProfile, value: any) => {
    setProfile({ ...profile, [field]: value });
  };

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* HEADER */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold flame-text mb-2">Settings</h1>
            <p className="text-gray-400">Personalize your AI companion</p>
          </div>
          <Link
            href="/dashboard"
            className="px-4 py-2 border border-gray-600 text-gray-400 rounded-lg hover:bg-gray-700"
          >
            ← Back
          </Link>
        </div>

        {/* SAVED INDICATOR */}
        {saved && (
          <div className="bg-green-900/30 border border-green-500 rounded-lg p-4 text-green-300">
            ✓ Settings saved successfully
          </div>
        )}

        {/* PRIVACY NOTICE */}
        <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-6">
          <h3 className="text-lg font-bold text-purple-300 mb-2">🔒 Privacy First</h3>
          <p className="text-sm text-gray-400">
            This information is used ONLY to personalize AI responses. We store your age TIER (not exact age),
            region CODE (not GPS), and never share this data. All settings stay on your device until you choose
            to sync with your account.
          </p>
        </div>

        {/* AGE TIER */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">Age Tier</h2>
          <p className="text-gray-400 mb-6">
            Helps AI provide age-appropriate guidance and context
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {AGE_TIERS.map((tier) => (
              <button
                key={tier.value}
                onClick={() => updateProfile("age_tier", tier.value)}
                className={`p-6 rounded-lg border-2 text-left transition-all ${
                  profile.age_tier === tier.value
                    ? "border-purple-500 bg-purple-900/30"
                    : "border-gray-600 bg-gray-800/50 hover:border-gray-500"
                }`}
              >
                <div className="font-semibold text-lg mb-2">{tier.label}</div>
                <div className="text-sm text-gray-400">{tier.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* GENDER */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">Gender</h2>
          <p className="text-gray-400 mb-6">
            For contextual advice (e.g., health, social situations)
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {GENDERS.map((gender) => (
              <button
                key={gender.value}
                onClick={() => updateProfile("gender", gender.value)}
                className={`p-4 rounded-lg border-2 transition-all ${
                  profile.gender === gender.value
                    ? "border-cyan-500 bg-cyan-900/30"
                    : "border-gray-600 bg-gray-800/50 hover:border-gray-500"
                }`}
              >
                <div className="font-semibold">{gender.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* REGION */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">Region</h2>
          <p className="text-gray-400 mb-6">
            For local crisis resources, cultural context, timezone (NO GPS tracking)
          </p>
          
          <div>
            <label className="block text-sm text-gray-400 mb-2">Select your state (US):</label>
            <select
              value={profile.region_code}
              onChange={(e) => updateProfile("region_code", e.target.value)}
              className="w-full bg-black/50 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
            >
              {US_STATES.map((state) => (
                <option key={state} value={state}>
                  {state.replace("US-", "")}
                </option>
              ))}
            </select>
            
            <div className="mt-4">
              <label className="block text-sm text-gray-400 mb-2">Or enter custom region code:</label>
              <input
                type="text"
                value={profile.region_code}
                onChange={(e) => updateProfile("region_code", e.target.value.toUpperCase())}
                placeholder="e.g., GB-SCT, CA-ON"
                className="w-full bg-black/50 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
              />
              <p className="text-xs text-gray-500 mt-2">
                Format: COUNTRY-REGION (e.g., US-NY, GB-SCT, CA-ON)
              </p>
            </div>
          </div>
        </div>

        {/* AI STYLE */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">AI Response Style</h2>
          <p className="text-gray-400 mb-6">
            How would you like the AI to communicate with you?
          </p>
          
          <div className="space-y-4">
            {AI_STYLES.map((style) => (
              <button
                key={style.value}
                onClick={() => updateProfile("ai_style", style.value)}
                disabled={style.value === "raw" && profile.age_tier === "teen"}
                className={`w-full p-6 rounded-lg border-2 text-left transition-all ${
                  profile.ai_style === style.value
                    ? "border-purple-500 bg-purple-900/30"
                    : "border-gray-600 bg-gray-800/50 hover:border-gray-500"
                } ${style.value === "raw" && profile.age_tier === "teen" ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                <div className="font-semibold text-lg mb-2">
                  {style.label}
                  {style.value === "raw" && " (18+ Only)"}
                </div>
                <div className="text-sm text-gray-400">{style.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* VOICE TONE */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">Voice Tone</h2>
          <p className="text-gray-400 mb-6">
            Personality of the AI voice (text and future audio)
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {VOICE_TONES.map((tone) => (
              <button
                key={tone.value}
                onClick={() => updateProfile("voice_tone", tone.value)}
                className={`p-6 rounded-lg border-2 transition-all ${
                  profile.voice_tone === tone.value
                    ? "border-cyan-500 bg-cyan-900/30"
                    : "border-gray-600 bg-gray-800/50 hover:border-gray-500"
                }`}
              >
                <div className="font-semibold text-lg mb-2">{tone.label}</div>
                <div className="text-sm text-gray-400">{tone.description}</div>
              </button>
            ))}
          </div>
        </div>

        {/* AVATAR NAME */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6">Avatar Name</h2>
          <p className="text-gray-400 mb-6">
            What do you want to call your Dual Flame companion?
          </p>
          
          <input
            type="text"
            value={profile.avatar_name}
            onChange={(e) => updateProfile("avatar_name", e.target.value)}
            placeholder="My Dual Flame"
            maxLength={30}
            className="w-full bg-black/50 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
          />
        </div>

        {/* SAVE BUTTON */}
        <div className="flex gap-4">
          <button
            onClick={saveProfile}
            className="flex-1 px-8 py-4 dual-flame-gradient text-white font-semibold rounded-lg hover:opacity-90"
          >
            Save Settings
          </button>
          <Link
            href="/dashboard"
            className="px-8 py-4 border-2 border-gray-600 text-gray-400 font-semibold rounded-lg hover:bg-gray-700"
          >
            Cancel
          </Link>
        </div>

        {/* EXAMPLE OUTPUT */}
        <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-6">
          <h3 className="font-semibold mb-4">Example AI Response for Your Settings:</h3>
          <div className="bg-black/50 rounded-lg p-4 text-gray-300">
            {profile.age_tier === "teen" && profile.ai_style === "plain" && (
              "School drama feels huge right now. It won't define you. You're stronger than the gossip."
            )}
            {profile.age_tier === "elder" && profile.ai_style === "poetic" && (
              "The sunset of life holds its own radiant beauty. Your wisdom is a lighthouse for those still navigating storms."
            )}
            {profile.age_tier === "adult" && profile.ai_style === "raw" && (
              "Life's kicking your ass right now. But you've survived worse. This pain is temporary. Your resilience isn't."
            )}
            {profile.age_tier === "midlife" && profile.ai_style === "empathetic" && (
              "You're carrying so much on your shoulders. It's okay to feel exhausted. Your strength doesn't mean you have to suffer alone."
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
