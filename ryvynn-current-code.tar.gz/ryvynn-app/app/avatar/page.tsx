"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";

// GROWING AVATAR SYSTEM (GAAS)
// Flame Evolution: Ember → Spark → Flame → Blaze → Inferno → Supernova
// Soul Tokens earned through engagement

type EvolutionLevel = "ember" | "spark" | "flame" | "blaze" | "inferno" | "supernova";

interface AvatarState {
  level: EvolutionLevel;
  xp: number;
  soul_tokens: number;
  total_confessions: number;
  total_miracles: number;
  streak_days: number;
  evolution_history: { level: EvolutionLevel; date: Date }[];
}

const EVOLUTION_THRESHOLDS = {
  ember: 0,
  spark: 100,
  flame: 500,
  blaze: 2000,
  inferno: 5000,
  supernova: 10000,
};

const LEVEL_NAMES = {
  ember: "Ember",
  spark: "Spark",
  flame: "Flame",
  blaze: "Blaze",
  inferno: "Inferno",
  supernova: "Supernova",
};

const LEVEL_COLORS = {
  ember: "#ff6b35",
  spark: "#f7931e",
  flame: "#ffd700",
  blaze: "#ff1493",
  inferno: "#9d00ff",
  supernova: "#00ffff",
};

const LEVEL_DESCRIPTIONS = {
  ember: "A small flicker in the darkness. Your journey begins.",
  spark: "The flame catches. You're building momentum.",
  flame: "Burning bright. Your light is visible to others.",
  blaze: "A force of nature. Your transformation is undeniable.",
  inferno: "Unstoppable. You're a beacon for those still in darkness.",
  supernova: "Transcendent. You've become pure light.",
};

export default function AvatarPage() {
  const [avatarState, setAvatarState] = useState<AvatarState>({
    level: "ember",
    xp: 0,
    soul_tokens: 10,
    total_confessions: 0,
    total_miracles: 0,
    streak_days: 0,
    evolution_history: [],
  });

  useEffect(() => {
    loadAvatarState();
  }, []);

  const loadAvatarState = () => {
    const stored = localStorage.getItem("avatar_state");
    if (stored) {
      setAvatarState(JSON.parse(stored));
    }
  };

  const getCurrentLevel = (xp: number): EvolutionLevel => {
    if (xp >= EVOLUTION_THRESHOLDS.supernova) return "supernova";
    if (xp >= EVOLUTION_THRESHOLDS.inferno) return "inferno";
    if (xp >= EVOLUTION_THRESHOLDS.blaze) return "blaze";
    if (xp >= EVOLUTION_THRESHOLDS.flame) return "flame";
    if (xp >= EVOLUTION_THRESHOLDS.spark) return "spark";
    return "ember";
  };

  const getNextLevelThreshold = (level: EvolutionLevel): number => {
    const levels: EvolutionLevel[] = ["ember", "spark", "flame", "blaze", "inferno", "supernova"];
    const currentIndex = levels.indexOf(level);
    if (currentIndex === levels.length - 1) return EVOLUTION_THRESHOLDS.supernova;
    return EVOLUTION_THRESHOLDS[levels[currentIndex + 1]];
  };

  const getProgressPercentage = (): number => {
    const nextThreshold = getNextLevelThreshold(avatarState.level);
    const prevThreshold = EVOLUTION_THRESHOLDS[avatarState.level];
    const progress = ((avatarState.xp - prevThreshold) / (nextThreshold - prevThreshold)) * 100;
    return Math.min(Math.max(progress, 0), 100);
  };

  const FlameVisualization = ({ level, size = "large" }: { level: EvolutionLevel; size?: "small" | "medium" | "large" }) => {
    const sizeMap = {
      small: "w-24 h-24",
      medium: "w-48 h-48",
      large: "w-64 h-64",
    };

    return (
      <div className={`relative ${sizeMap[size]} mx-auto`}>
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle, ${LEVEL_COLORS[level]}40, ${LEVEL_COLORS[level]}10, transparent)`,
            filter: "blur(20px)",
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
        <motion.div
          className="absolute inset-0 flex items-center justify-center text-8xl"
          animate={{
            rotate: [0, 10, -10, 0],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          🔥
        </motion.div>
        <svg className="absolute inset-0 w-full h-full" style={{ filter: "drop-shadow(0 0 20px " + LEVEL_COLORS[level] + ")" }}>
          <circle
            cx="50%"
            cy="50%"
            r="45%"
            fill="none"
            stroke={LEVEL_COLORS[level]}
            strokeWidth="2"
            opacity="0.3"
          />
          <circle
            cx="50%"
            cy="50%"
            r="40%"
            fill="none"
            stroke={LEVEL_COLORS[level]}
            strokeWidth="1"
            opacity="0.5"
          />
        </svg>
      </div>
    );
  };

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* HEADER */}
        <div className="text-center space-y-4">
          <h1 className="text-6xl font-bold flame-text">Growing Avatar System</h1>
          <p className="text-2xl text-gray-400">
            Your Journey Visualized. Your Soul Made Visible.
          </p>
        </div>

        {/* MAIN FLAME VISUALIZATION */}
        <div className="bg-gradient-to-br from-gray-900 to-black rounded-lg p-12 border border-gray-700">
          <FlameVisualization level={avatarState.level} size="large" />
          
          <div className="text-center mt-8 space-y-4">
            <h2 className="text-4xl font-bold" style={{ color: LEVEL_COLORS[avatarState.level] }}>
              {LEVEL_NAMES[avatarState.level]}
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              {LEVEL_DESCRIPTIONS[avatarState.level]}
            </p>
          </div>

          {/* XP PROGRESS BAR */}
          <div className="mt-8 max-w-2xl mx-auto">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">
                {avatarState.xp} XP
              </span>
              <span className="text-sm text-gray-400">
                {getNextLevelThreshold(avatarState.level)} XP (Next Level)
              </span>
            </div>
            <div className="w-full h-4 bg-gray-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: LEVEL_COLORS[avatarState.level] }}
                initial={{ width: 0 }}
                animate={{ width: `${getProgressPercentage()}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
          </div>
        </div>

        {/* SOUL TOKENS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-purple-900/30 to-gray-900 rounded-lg p-8 border border-purple-500/30">
            <div className="text-6xl mb-4">💎</div>
            <div className="text-4xl font-bold text-purple-300 mb-2">
              {avatarState.soul_tokens}
            </div>
            <div className="text-sm text-gray-400">Soul Tokens</div>
            <p className="text-xs text-gray-500 mt-2">
              Earned through confessions, miracles, and daily engagement
            </p>
          </div>

          <div className="bg-gradient-to-br from-cyan-900/30 to-gray-900 rounded-lg p-8 border border-cyan-500/30">
            <div className="text-6xl mb-4">✨</div>
            <div className="text-4xl font-bold text-cyan-300 mb-2">
              {avatarState.total_miracles}
            </div>
            <div className="text-sm text-gray-400">Miracles Created</div>
            <p className="text-xs text-gray-500 mt-2">
              Confessions transformed into hope
            </p>
          </div>

          <div className="bg-gradient-to-br from-orange-900/30 to-gray-900 rounded-lg p-8 border border-orange-500/30">
            <div className="text-6xl mb-4">🔥</div>
            <div className="text-4xl font-bold text-orange-300 mb-2">
              {avatarState.streak_days}
            </div>
            <div className="text-sm text-gray-400">Day Streak</div>
            <p className="text-xs text-gray-500 mt-2">
              Consecutive days of engagement
            </p>
          </div>
        </div>

        {/* EVOLUTION PATH */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-8 border border-gray-700">
          <h3 className="text-2xl font-bold mb-8 text-center">Evolution Path</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {(Object.keys(EVOLUTION_THRESHOLDS) as EvolutionLevel[]).map((level) => {
              const isUnlocked = avatarState.xp >= EVOLUTION_THRESHOLDS[level];
              const isCurrent = avatarState.level === level;
              
              return (
                <div
                  key={level}
                  className={`relative text-center p-4 rounded-lg border-2 ${
                    isCurrent
                      ? "border-white bg-white/10"
                      : isUnlocked
                      ? "border-gray-600 bg-gray-800/50"
                      : "border-gray-800 bg-gray-900/30 opacity-50"
                  }`}
                >
                  <FlameVisualization level={level} size="small" />
                  <div
                    className="font-bold mt-2"
                    style={{ color: isUnlocked ? LEVEL_COLORS[level] : "#666" }}
                  >
                    {LEVEL_NAMES[level]}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {EVOLUTION_THRESHOLDS[level]} XP
                  </div>
                  {isCurrent && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                      ✓
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* EARN MORE XP */}
        <div className="bg-gradient-to-br from-purple-900/20 to-gray-900 rounded-lg p-8 border border-purple-500/30">
          <h3 className="text-2xl font-bold mb-6">Earn More XP</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-4 p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl">📝</div>
              <div>
                <div className="font-semibold text-purple-300">Write a Confession</div>
                <div className="text-sm text-gray-400">+10 XP, +2 Soul Tokens</div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl">✨</div>
              <div>
                <div className="font-semibold text-purple-300">Transform to Miracle</div>
                <div className="text-sm text-gray-400">+25 XP, +5 Soul Tokens</div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl">🔥</div>
              <div>
                <div className="font-semibold text-purple-300">Daily Check-In</div>
                <div className="text-sm text-gray-400">+5 XP, +2 Soul Tokens</div>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-gray-800/50 rounded-lg">
              <div className="text-2xl">🙏</div>
              <div>
                <div className="font-semibold text-purple-300">Witness a Miracle</div>
                <div className="text-sm text-gray-400">+2 XP, +1 Soul Token</div>
              </div>
            </div>
          </div>
        </div>

        {/* BACK BUTTON */}
        <div className="text-center">
          <Link
            href="/dashboard"
            className="inline-block px-8 py-4 border-2 border-purple-500 text-purple-300 font-semibold rounded-lg hover:bg-purple-500/10 transition-colors"
          >
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
