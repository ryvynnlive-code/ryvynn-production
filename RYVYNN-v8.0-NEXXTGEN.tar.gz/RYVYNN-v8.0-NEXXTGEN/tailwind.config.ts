import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Dual Flame Color Palette
        flame: {
          ember: "#FF6B35",
          spark: "#FF8C42",
          flame: "#FFA500",
          blaze: "#FFB84D",
          inferno: "#FFD700",
          supernova: "#FFF4CC",
        },
        cosmic: {
          void: "#000000",
          deep: "#0A0A0F",
          space: "#1A1A2E",
          nebula: "#2D2D44",
          star: "#4A4A6A",
        },
        soul: {
          dark: "#1E1E2E",
          shadow: "#2E2E3E",
          glow: "#3E3E5E",
          light: "#5E5E7E",
          bright: "#7E7E9E",
        },
      },
      animation: {
        "flame-flicker": "flameFlicker 2s ease-in-out infinite",
        "glow-pulse": "glowPulse 3s ease-in-out infinite",
        "float": "float 6s ease-in-out infinite",
      },
      keyframes: {
        flameFlicker: {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.8", transform: "scale(1.05)" },
        },
        glowPulse: {
          "0%, 100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
