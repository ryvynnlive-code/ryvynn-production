/**
 * MAR 3.0 (Miracle Adaptive Response Engine)
 * RYVYNN v8.0 NEXXT GEN
 * 
 * Core AI transformation engine that converts confessions into miracles
 * with context-aware personalization based on age, gender, region, and style preferences.
 */

import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

export interface ConfessionContext {
  confession: string;
  ageTier?: "teen" | "young_adult" | "adult" | "midlife" | "mature" | "elder";
  gender?: "male" | "female" | "non_binary" | "prefer_not_to_say";
  regionCode?: string; // ISO 3166-2 (e.g., "US-NY", "GB-SCT")
  responseStyle?: "plain" | "poetic" | "direct" | "clinical" | "empathetic";
}

export interface MiracleResponse {
  miracle: string;
  crisisDetected: boolean;
  crisisLevel: number; // 0-10
  keywordsFound: string[];
  sentimentTone: "dark" | "neutral" | "hopeful";
}

// Crisis keywords for detection
const CRISIS_KEYWORDS = [
  "suicide", "kill myself", "end it all", "better off dead",
  "want to die", "hopeless", "worthless", "no reason to live",
  "give up", "harm myself", "self-harm", "cut myself",
];

/**
 * Detect crisis level in confession text
 */
function detectCrisis(text: string): { detected: boolean; level: number; keywords: string[] } {
  const lowerText = text.toLowerCase();
  const foundKeywords = CRISIS_KEYWORDS.filter((keyword) =>
    lowerText.includes(keyword.toLowerCase())
  );

  const detected = foundKeywords.length > 0;
  const level = detected ? Math.min(foundKeywords.length * 2, 10) : 0;

  return { detected, level, keywords: foundKeywords };
}

/**
 * Build context-aware system prompt based on user demographics
 */
function buildSystemPrompt(context: ConfessionContext): string {
  const { ageTier, gender, regionCode, responseStyle = "poetic" } = context;

  let prompt = `You are RYVYNN, a compassionate AI companion for mental wellness. Your role is to transform confessions into "miracles" - messages of hope, wisdom, and light.

CORE PRINCIPLES:
- Never judge, always understand
- Acknowledge pain, offer perspective  
- Find meaning in darkness
- Guide toward hope without toxic positivity
- Respect anonymity and privacy

CONTEXT:`;

  // Age-appropriate context
  if (ageTier) {
    const ageContext: Record<string, string> = {
      teen: "Speaking to a teenager (13-17). Use age-appropriate language, acknowledge school/identity struggles, peer pressure, finding self.",
      young_adult: "Speaking to young adult (18-25). Address career uncertainty, relationships, finding purpose, independence.",
      adult: "Speaking to adult (26-35). Focus on balance, responsibility, career growth, relationships, building life.",
      midlife: "Speaking to midlife individual (36-50). Acknowledge life transitions, reflection, career shifts, family dynamics.",
      mature: "Speaking to mature individual (51-65). Honor experience, legacy, wisdom, life review.",
      elder: "Speaking to elder (66+). Respect deep wisdom, life completion themes, legacy, acceptance.",
    };
    prompt += `\n- Age Context: ${ageContext[ageTier]}`;
  }

  // Gender context
  if (gender && gender !== "prefer_not_to_say") {
    prompt += `\n- Gender: ${gender} (Be mindful of gender-specific struggles and societal expectations)`;
  }

  // Regional context
  if (regionCode) {
    prompt += `\n- Region: ${regionCode} (Cultural context awareness, local resources)`;
  }

  // Response style
  const styleGuide: Record<string, string> = {
    plain: "Use simple, direct language at 4th-5th grade reading level. No poetry or metaphors. Clear and straightforward.",
    poetic: "Use eloquent, symbolic language. Metaphors, imagery, and finding beauty in darkness. Lyrical and profound.",
    direct: "Unfiltered, raw truth. No sugar-coating. Honest and straightforward. Tell it like it is.",
    clinical: "Professional, therapeutic language. Evidence-based, structured response. Formal and clear.",
    empathetic: "Warm, compassionate, deeply understanding. Gentle and nurturing. Hold space for pain.",
  };

  prompt += `\n\nRESPONSE STYLE: ${styleGuide[responseStyle]}`;

  prompt += `\n\nIMPORTANT:
- Keep responses under 250 words
- End with subtle hope, never forced
- Use "you" to address them directly
- Never mention being an AI
- Transform darkness into light naturally
- Honor the darkness first before offering light
- No clichés or platitudes`;

  return prompt;
}

/**
 * Transform confession into miracle using MAR 3.0
 * This is the core engine that powers RYVYNN
 */
export async function transformConfession(
  context: ConfessionContext
): Promise<MiracleResponse> {
  const { confession } = context;

  // Step 1: Crisis detection (ALWAYS first)
  const crisis = detectCrisis(confession);

  // Step 2: Build context-aware system prompt
  const systemPrompt = buildSystemPrompt(context);

  // Step 3: Generate miracle with Claude Sonnet 4.5
  const message = await client.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 1024,
    temperature: 0.8,
    system: systemPrompt,
    messages: [
      {
        role: "user",
        content: `Transform this confession into a miracle:\n\n"${confession}"`,
      },
    ],
  });

  // Extract miracle text
  const miracle = message.content[0].type === "text" ? message.content[0].text : "";

  // Step 4: Determine sentiment tone
  const confessionLower = confession.toLowerCase();
  const sentimentTone = crisis.detected
    ? "dark"
    : confessionLower.includes("hope") ||
      confessionLower.includes("better") ||
      confessionLower.includes("grateful") ||
      confessionLower.includes("thankful")
    ? "hopeful"
    : "neutral";

  return {
    miracle,
    crisisDetected: crisis.detected,
    crisisLevel: crisis.level,
    keywordsFound: crisis.keywords,
    sentimentTone,
  };
}

/**
 * Get local crisis resources based on region code
 */
export function getCrisisResources(regionCode?: string): {
  hotline: string;
  textLine: string;
  localResources?: string[];
} {
  // Universal crisis resources
  const universal = {
    hotline: "988 (Suicide & Crisis Lifeline)",
    textLine: "Text HOME to 741741 (Crisis Text Line)",
  };

  // Region-specific resources (can be expanded)
  const regionalResources: Record<string, string[]> = {
    "US-NY": ["NYC Well: 888-692-9355", "Trevor Project (LGBTQ): 1-866-488-7386"],
    "US-CA": ["California Crisis Line: 1-800-273-8255"],
    "GB-SCT": ["Samaritans: 116 123", "Breathing Space: 0800 83 85 87"],
    "GB-ENG": ["Samaritans: 116 123", "CALM (Men): 0800 58 58 58"],
  };

  return {
    ...universal,
    localResources: regionCode ? regionalResources[regionCode] : undefined,
  };
}
