# 🔥 RYVYNN v8.0 DEPLOYMENT GUIDE

Complete step-by-step deployment to production.

---

## 📋 PRE-DEPLOYMENT CHECKLIST

### 1. Supabase Setup
- [ ] Create Supabase project at https://supabase.com
- [ ] Enable Row Level Security (RLS)
- [ ] Install pgvector extension
- [ ] Copy connection strings
- [ ] Generate service role key

### 2. Anthropic Setup  
- [ ] Get API key from https://console.anthropic.com
- [ ] Verify Sonnet 4.5 access
- [ ] Test API connection

### 3. Stripe Setup
- [ ] Create Stripe account at https://stripe.com
- [ ] Create Tesla Grid products:
  - Spark: $12/mo, $96/yr
  - Blaze: $36/mo, $288/yr
  - Inferno: $94/mo, $749/yr
  - Transcendent: $936/mo, $7,488/yr
- [ ] Configure webhook endpoint
- [ ] Get API keys

### 4. Domain Setup
- [ ] Register ryvynn.live (if needed)
- [ ] Configure DNS records
- [ ] Set up SSL certificate

---

## 🚀 DEPLOYMENT STEPS

### Step 1: Install Dependencies
```bash
cd RYVYNN-v8.0-NEXXTGEN
npm install
```

### Step 2: Configure Environment
```bash
cp .env.example .env.local
# Edit .env.local with your keys
```

### Step 3: Initialize Database
```bash
npx prisma db push
npx prisma generate
```

### Step 4: Test Locally
```bash
npm run dev
```
Visit http://localhost:3000

### Step 5: Deploy to Vercel

**Option A: GitHub Integration** (Recommended)
```bash
# Initialize git
git init
git add .
git commit -m "RYVYNN v8.0 NEXXT GEN - Complete Build"

# Create GitHub repo
gh repo create ryvynn-app --private

# Push code
git push -u origin main
```

Then:
1. Go to https://vercel.com/dashboard
2. Click "Add New Project"
3. Import from GitHub: `ryvynn-app`
4. Add environment variables
5. Deploy

**Option B: Vercel CLI**
```bash
npm install -g vercel
vercel login
vercel --prod
```

Add environment variables via Vercel dashboard.

### Step 6: Configure Stripe Webhook
```bash
# Get your Vercel deployment URL
# Add webhook endpoint in Stripe dashboard:
# https://ryvynn.live/api/stripe/webhook

# Events to listen for:
# - checkout.session.completed
# - customer.subscription.created
# - customer.subscription.updated
# - customer.subscription.deleted
```

### Step 7: Verify Deployment
- [ ] Homepage loads
- [ ] Confession form works
- [ ] AI transformation works
- [ ] Crisis detection triggers
- [ ] Stripe checkout works
- [ ] Database connections active

---

## 🔑 ENVIRONMENT VARIABLES

### Required
```env
DATABASE_URL                     # Supabase connection string
DIRECT_URL                       # Supabase direct connection
NEXT_PUBLIC_SUPABASE_URL         # Supabase project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY    # Supabase anon key
SUPABASE_SERVICE_ROLE_KEY        # Supabase service key
ANTHROPIC_API_KEY                # Claude API key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY  # Stripe publishable key
STRIPE_SECRET_KEY                # Stripe secret key
STRIPE_WEBHOOK_SECRET            # Stripe webhook secret
NEXT_PUBLIC_APP_URL              # Production URL
```

### Optional
```env
NODE_ENV=production
VERCEL_ENV=production
```

---

## ⚙️ POST-DEPLOYMENT

### 1. Test Core Features
```bash
# Test confession submission
curl -X POST https://ryvynn.live/api/confess \
  -H "Content-Type: application/json" \
  -d '{"confession": "test confession"}'

# Test health check
curl https://ryvynn.live/api/health
```

### 2. Monitor Logs
```bash
vercel logs --prod
```

### 3. Set Up Analytics
- Vercel Analytics automatically enabled
- Check dashboard at https://vercel.com/dashboard/analytics

### 4. Crisis Testing
1. Submit confession with crisis keywords
2. Verify 988 banner displays
3. Test emergency contact notification

### 5. Payment Testing
1. Use Stripe test cards
2. Verify webhook processing
3. Test subscription upgrades/downgrades

---

## 🐛 TROUBLESHOOTING

### Database Connection Issues
```bash
# Verify connection string
psql "$DATABASE_URL"

# Check RLS policies
psql "$DATABASE_URL" -c "SELECT * FROM pg_policies;"
```

### Stripe Webhook Issues
```bash
# Test webhook locally
stripe listen --forward-to localhost:3000/api/stripe/webhook

# Verify webhook secret
stripe webhooks list
```

### Build Failures
```bash
# Clear cache
rm -rf .next node_modules
npm install
npm run build
```

---

## 📊 MONITORING

### Key Metrics to Track
- Response times (API routes)
- Error rates
- Crisis event frequency
- User registrations
- Subscription conversions
- Database query performance

### Vercel Dashboard
- Monitor at https://vercel.com/dashboard
- Check deployment logs
- Review analytics
- Monitor function execution

### Supabase Dashboard
- Database health
- API usage
- Storage usage
- RLS policy effectiveness

---

## 🔒 SECURITY CHECKLIST

- [ ] Environment variables in Vercel (never in code)
- [ ] RLS enabled on all tables
- [ ] HTTPS enforced
- [ ] API rate limiting configured
- [ ] Webhook signature verification active
- [ ] Database backups enabled
- [ ] Error logging (no sensitive data)

---

## 📈 SCALING

### Performance Optimization
- Enable Vercel Edge Functions
- Use Supabase connection pooling
- Implement caching strategy
- Optimize database queries
- Add CDN for static assets

### High-Traffic Preparation
- Upgrade Vercel plan if needed
- Scale Supabase compute
- Monitor API rate limits
- Implement queue system for heavy tasks

---

## 🆘 SUPPORT

**Technical Issues**: shawn@ryvynn.live  
**Deployment Help**: Create issue on GitHub  
**Emergency**: Contact NEXXT GEN INNOVATIONS LLC

---

## 🔄 UPDATES

### Deploy Updates
```bash
git add .
git commit -m "Update: [description]"
git push
```

Vercel auto-deploys on push to main branch.

### Database Migrations
```bash
npx prisma migrate dev --name [migration_name]
npx prisma migrate deploy
```

---

## ✅ SUCCESS CRITERIA

Deployment is successful when:
- All API endpoints respond 200 OK
- Crisis detection triggers correctly
- Stripe payments process
- Database queries execute
- No console errors
- Lighthouse score > 90

---

**TARGET LAUNCH**: Q1 2026  
**TARGET USERS**: 10M by 2030  
**TARGET IMPACT**: Lives Saved

*From Our Darkest Hours to Our Brightest Days* 🔥🔥🔥
